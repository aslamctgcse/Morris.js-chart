<?php 
//index.php
$connect = mysqli_connect("localhost", "root", "", "testing");
$query = "SELECT * FROM account";
$result = mysqli_query($connect, $query);
$chart_data = '';
while($row = mysqli_fetch_array($result))
{
 $chart_data .= "{ year:'".$row["year"]."', profit:".$row["profit"].", purchase:".$row["purchase"].", sale:".$row["sale"]."}, ";
}
$chart_data = substr($chart_data, 0, -2);
?>

<!DOCTYPE html>
<html>
<h1>Morris.js chart</h1>
 <head>
  <title>Webslesson Tutorial | How to use Morris.js chart with PHP & Mysql</title>
  <link rel="stylesheet" href="css/morris.css">
  <script src="css/jquery.min.js"></script>
  <script src="css/raphael-min.js"></script>
  <script src="css/morris.min.js"></script>
  
 </head>
 <body>
 	<h2><a href="https://www.youtube.com/watch?v=ktUOY0OAFmA">Source video:</i></a></h2>
 	<h2><a href="https://www.webslesson.info/2017/03/morrisjs-chart-with-php-mysql.html">Source Code:</i></a></h2>
  <br /><br />
  <div class="container" style="width:auto;">
   <h2 align="center">Morris.js chart with PHP & Mysql [Morris.Line]</h2>
   <br /><br />
   <div id="chart"></div>
  </div>

   <br /><br />
  <div class="container" style="width:auto;">
   <h2 align="center">Morris.js chart with PHP & Mysql [Morris.Area]</h2>
   <br /><br />
   <div id="chart2"></div>
  </div>

  <br /><br />
  <div class="container" style="width:auto;">
   <h2 align="center">Morris.js chart with PHP & Mysql [Morris.Bar]</h2>
   <br /><br />
   <div id="chart3"></div>
  </div>

   <br /><br />
  <div class="container" style="width:auto;">
   <h2 align="center">Morris.js chart with PHP & Mysql[Morris.Bar[stacked:true]]</h2>
   <br /><br />
   <div id="chart4"></div>
  </div>

   <br /><br />
  <div class="container" style="width:auto;">
   <h2 align="center">Morris.js chart with PHP & Mysql [Morris.Donut]</h2>
   <br /><br />
   <div id="chart5"></div>
  </div>

 </body>
</html>

<script>
Morris.Line({
 element : 'chart',
 data:[<?php echo $chart_data; ?>],
 xkey:'year',
 ykeys:['profit', 'purchase', 'sale'],
 labels:['Profit', 'Purchase', 'Sale'],
 hideHover:'auto',
 stacked:true
});
</script>

<script>
Morris.Area({
 element : 'chart2',
 data:[<?php echo $chart_data; ?>],
 xkey:'year',
 ykeys:['profit', 'purchase', 'sale'],
 labels:['Profit', 'Purchase', 'Sale'],
 hideHover:'auto',
 stacked:true
});
</script>

<script>
Morris.Bar({
 element : 'chart3',
 data:[<?php echo $chart_data; ?>],
 xkey:'year',
 ykeys:['profit', 'purchase', 'sale'],
 labels:['Profit', 'Purchase', 'Sale'],
 hideHover:'auto',
});
</script>

<script>
Morris.Bar({
 element : 'chart4',
 data:[<?php echo $chart_data; ?>],
 xkey:'year',
 ykeys:['profit', 'purchase', 'sale'],
 labels:['Profit', 'Purchase', 'Sale'],
 hideHover:'auto',
 stacked:true
});
</script>

<script>
	Morris.Donut({
  	element: 'chart5',
  	data: [
    {label: "Download Sales", value: 33},
    {label: "In-Store Sales", value: 33},
    {label: "Mail-Order Sales", value: 34}
  ]
});

Morris.Donut({
 element : 'char5',
 data:[<?php echo $chart_data; ?>],
 xkey:'year',
 ykeys:['profit', 'purchase', 'sale'],
 labels:['Profit', 'Purchase', 'Sale'],
 hideHover:'auto',
 stacked:true
});
</script>